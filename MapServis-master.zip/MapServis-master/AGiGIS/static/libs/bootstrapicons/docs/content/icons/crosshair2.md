---
title: Crosshair2
categories:
  - Geo
tags:
  - geography
  - map
  - pin
  - location
added: 1.11.0
---
