---
title: Explicit fill
categories:
  - Badges
tags:
  - r18
---
