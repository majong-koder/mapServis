---
title: Currency rupee
categories:
  - Commerce
tags:
  - money
  - finance
---
