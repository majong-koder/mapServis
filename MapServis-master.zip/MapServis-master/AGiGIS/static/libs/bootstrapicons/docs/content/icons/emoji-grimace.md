---
title: Emoji grimace
categories:
  - Emoji
tags:
  - emoticon
added: 1.11.0
---
