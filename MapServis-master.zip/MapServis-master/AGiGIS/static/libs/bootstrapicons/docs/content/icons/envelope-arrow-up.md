---
title: Envelope arrow up
categories:
  - Communications
tags:
  - email
  - message
  - mail
  - letter
added: 1.11.0
---
