---
title: Clipboard2 pulse fill
categories:
  - Real world
  - Medical
tags:
  - copy
  - paste
  - heartrate
---
