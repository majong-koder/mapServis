---
title: Currency euro
categories:
  - Commerce
tags:
  - money
  - finance
---
