---
title: Emoji astonished
categories:
  - Emoji
tags:
  - emoticon
  - surprised
added: 1.11.0
---
