---
title: Currency yen
categories:
  - Commerce
tags:
  - money
  - finance
---
