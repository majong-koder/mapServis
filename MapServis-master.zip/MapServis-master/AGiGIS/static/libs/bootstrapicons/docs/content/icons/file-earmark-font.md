---
title: File earmark font
categories:
  - Files and folders
tags:
  - ttf
  - otf
---
