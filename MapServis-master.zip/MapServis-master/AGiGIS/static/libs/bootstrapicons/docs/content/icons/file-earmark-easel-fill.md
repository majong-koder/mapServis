---
title: File earmark easel fill
categories:
  - Files and folders
tags:
  - slides
  - presentation
  - powerpoint
  - keynote
---
