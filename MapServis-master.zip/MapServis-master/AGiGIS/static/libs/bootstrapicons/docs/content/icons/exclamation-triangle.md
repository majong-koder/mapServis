---
title: Exclamation triangle
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
