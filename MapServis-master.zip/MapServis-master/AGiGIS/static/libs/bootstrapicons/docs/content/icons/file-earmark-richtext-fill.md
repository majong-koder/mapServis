---
title: File earmark richtext fill
categories:
  - Files and folders
tags:
  - text
  - doc
  - document
---
