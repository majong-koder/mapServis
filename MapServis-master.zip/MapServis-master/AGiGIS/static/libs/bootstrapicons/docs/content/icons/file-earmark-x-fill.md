---
title: File earmark x fill
categories:
  - Files and folders
tags:
  - document
  - remove
  - delete
---
