---
title: Copy
categories:
  - UI and keyboard
tags:
  - paste
  - clone
  - cut
  - duplicate
added: 1.11.0
---
