---
title: File earmark word
categories:
  - Files and folders
tags:
  - doc
  - document
---
