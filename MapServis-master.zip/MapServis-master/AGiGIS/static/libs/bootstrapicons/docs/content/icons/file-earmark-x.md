---
title: File earmark x
categories:
  - Files and folders
tags:
  - document
  - remove
  - delete
---
