---
title: Emoji neutral
categories:
  - Emoji
tags:
  - emoticon
  - expressionless
---
