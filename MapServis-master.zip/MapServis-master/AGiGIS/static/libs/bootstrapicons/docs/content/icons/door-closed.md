---
title: Door closed
categories:
  - Real world
tags:
  - door
  - logout
  - signout
---
