---
title: Eyedropper
categories:
  - Graphics
tags:
  - color
  - picker
---
