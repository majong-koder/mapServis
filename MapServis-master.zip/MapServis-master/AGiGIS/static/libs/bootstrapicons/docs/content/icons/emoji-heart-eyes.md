---
title: Emoji heart eyes
categories:
  - Emoji
tags:
  - emoticon
  - heart
  - love
---
