---
title: Dpad
categories:
  - Entertainment
tags:
  - gaming
  - controller
  - direction
---
