---
title: Ethernet
categories:
  - Devices
tags:
  - internet
  - connection
  - port
  - plug
---
