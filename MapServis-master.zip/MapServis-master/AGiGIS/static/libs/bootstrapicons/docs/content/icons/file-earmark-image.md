---
title: File earmark image
categories:
  - Files and folders
tags:
  - photo
  - picture
---
