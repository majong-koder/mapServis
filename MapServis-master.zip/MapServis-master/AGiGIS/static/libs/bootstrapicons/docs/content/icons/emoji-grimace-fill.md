---
title: Emoji grimace fill
categories:
  - Emoji
tags:
  - emoticon
added: 1.11.0
---
