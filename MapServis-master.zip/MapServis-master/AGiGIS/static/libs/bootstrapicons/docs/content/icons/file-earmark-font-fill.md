---
title: File earmark font fill
categories:
  - Files and folders
tags:
  - ttf
  - otf
---
