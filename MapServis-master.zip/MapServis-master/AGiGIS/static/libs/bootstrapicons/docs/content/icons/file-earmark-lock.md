---
title: File earmark lock
categories:
  - Files and folders
tags:
  - lock
  - private
  - secure
---
