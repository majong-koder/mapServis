---
title: Emoji wink fill
categories:
  - Emoji
tags:
  - emoticon
---
