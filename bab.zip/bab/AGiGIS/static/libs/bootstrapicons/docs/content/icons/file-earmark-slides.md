---
title: File earmark slides
categories:
  - Files and folders
tags:
  - presentation
  - keynote
  - powerpoint
---
