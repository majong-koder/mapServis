---
title: Emoji angry fill
categories:
  - Emoji
tags:
  - emoticon
  - anger
  - upset
---
