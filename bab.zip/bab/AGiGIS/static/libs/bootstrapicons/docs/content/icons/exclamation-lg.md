---
title: Exclamation lg
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
