---
title: Feather
categories:
  - Real World
tags:
  - bird
  - flight
  - light
added: 1.11.0
---
