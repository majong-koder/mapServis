---
title: File earmark minus fill
categories:
  - Files and folders
tags:
  - doc
  - document
  - delete
  - remove
---
