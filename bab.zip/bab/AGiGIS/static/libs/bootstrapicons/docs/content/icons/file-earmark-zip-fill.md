---
title: File earmark zip fill
categories:
  - Files and folders
tags:
  - doc
  - document
  - zip
  - archive
  - compress
---
