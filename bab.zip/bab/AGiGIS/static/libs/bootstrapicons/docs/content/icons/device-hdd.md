---
title: Device HDD
categories:
  - Devices
tags:
  - drive
  - "hard drive"
---
