---
title: Cup hot fill
categories:
  - Real world
tags:
  - mug
  - steam
  - coffee
  - tea
---
