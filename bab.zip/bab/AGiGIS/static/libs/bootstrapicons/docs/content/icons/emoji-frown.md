---
title: Emoji frown
categories:
  - Emoji
tags:
  - emoticon
  - sad
---
