---
title: Fast forward
categories:
  - Media
tags:
  - audio
  - video
  - av
---
