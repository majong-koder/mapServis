---
title: Code square
categories:
  - Typography
tags:
  - text
  - type
  - code
  - developer
  - development
  - software
  - preformatted
added: 1.10.0
---
