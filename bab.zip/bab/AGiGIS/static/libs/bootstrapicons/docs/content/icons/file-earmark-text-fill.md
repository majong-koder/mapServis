---
title: File earmark text fill
categories:
  - Files and folders
tags:
  - doc
  - document
---
