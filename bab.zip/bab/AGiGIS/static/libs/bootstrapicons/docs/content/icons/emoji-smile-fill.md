---
title: Emoji smile fill
categories:
  - Emoji
tags:
  - emoticon
  - happy
---
