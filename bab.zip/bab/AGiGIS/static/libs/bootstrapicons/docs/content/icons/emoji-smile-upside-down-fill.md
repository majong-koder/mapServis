---
title: Emoji smile upside down fill
categories:
  - Emoji
tags:
  - emoticon
  - sarcasm
---
