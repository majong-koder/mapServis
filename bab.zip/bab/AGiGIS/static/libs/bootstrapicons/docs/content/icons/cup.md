---
title: Cup
categories:
  - Real world
tags:
  - mug
---
