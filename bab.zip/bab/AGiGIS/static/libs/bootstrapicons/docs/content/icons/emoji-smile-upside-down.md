---
title: Emoji smile upside down
categories:
  - Emoji
tags:
  - emoticon
  - sarcasm
---
