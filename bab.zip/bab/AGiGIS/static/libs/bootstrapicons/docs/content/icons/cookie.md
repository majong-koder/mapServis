---
title: Cookie
categories:
  - Real World
tags:
  - dessert
added: 1.11.0
---
